return {
  {
    "mfussenegger/nvim-dap",
    keys = {
      { "<leader>dd", desc = "DAP: Build & Debug" },
      { "<leader>dr", desc = "DAP: Build & Run" },
      { "<leader>db", desc = "DAP: Build Release" },
      { "<leader>dx", desc = "DAP: Terminate" },
      { "<leader>du", desc = "DAP: Toggle UI" },
      { "<leader>dv", desc = "DAP: Eval expression (hover)" },
      { "<leader>b",  desc = "DAP: Toggle Breakpoint" },
      { "<leader>B",  desc = "DAP: Conditional Breakpoint" },
      { "<F5>",       desc = "DAP: Continue" },
      { "<F4>",       desc = "DAP: Restart" },
      { "<F6>",       desc = "DAP: Step Over" },
      { "<F7>",       desc = "DAP: Step Into" },
      { "<F8>",       desc = "DAP: Step Out" },
      { "<F9>",       desc = "DAP: Open REPL" },
    },
    dependencies = {
      -- Single source of truth for nvim-dap-view
      {
        "igorlfs/nvim-dap-view",
        opts = {
          winbar = {
            sections = { "watches", "scopes", "exceptions", "breakpoints", "threads", "repl", "console" },
            default_section = "watches",
            show_keymap_hints = true,
            controls = {
              enabled = true,
              position = "right",
              buttons = { "play", "step_into", "step_over", "step_out", "run_last", "terminate" },
            },
          },
          windows = {
            size = 0.35,
            position = "right",
            terminal = {
              size = 0.30,
              position = "bottom",
              hide = {},
            },
          },
        },
      },
      "jay-babu/mason-nvim-dap.nvim",
      "mfussenegger/nvim-dap-python",
    },
    config = function()
      local dap = require("dap")

      -- Load dap-view with error reporting
      local dapview_ok, dapview = pcall(require, "dap-view")
      if not dapview_ok then
        vim.notify("[dap-view] ERROR: " .. tostring(dapview), vim.log.levels.ERROR)
      end

      -- Mason setup
      require("mason-nvim-dap").setup({
        ensure_installed = { "python", "cppdbg" },
        automatic_installation = true,
      })

      -- Auto open/close dap-view if available
      if dapview_ok then
        dap.listeners.before.attach["dapview_config"] = function() dapview.open() end
        dap.listeners.before.launch["dapview_config"] = function() dapview.open() end
        dap.listeners.before.event_terminated["dapview_config"] = function() dapview.close() end
        dap.listeners.before.event_exited["dapview_config"] = function() dapview.close() end
      end

      -- cppdbg adapter
      dap.adapters.cppdbg = {
        id = "cppdbg",
        type = "executable",
        command = vim.fn.stdpath("data") .. "/mason/packages/cpptools/extension/debugAdapters/bin/OpenDebugAD7",
      }

      -- CMake helpers (unchanged)
      local function cmake_find_root(start_dir)
        local dir = start_dir
        for _ = 1, 10 do
          if vim.fn.filereadable(dir .. "/CMakeLists.txt") == 1 then return dir end
          local parent = vim.fn.fnamemodify(dir, ":h")
          if parent == dir then break end
          dir = parent
        end
        return nil
      end

      local function cmake_get_exe_name(root)
        for _, line in ipairs(vim.fn.readfile(root .. "/CMakeLists.txt")) do
          local name = line:match("add_executable%s*%(%s*(%S+)")
          if name then return name end
        end
        return nil
      end

      local function cmake_build(root, build_type)
        build_type = build_type or "Debug"
        local build_dir = root .. "/build/" .. build_type:lower()
        if vim.fn.isdirectory(build_dir) == 0 then vim.fn.mkdir(build_dir, "p") end

        local cfg_out = vim.fn.system(string.format(
          "cmake -S %s -B %s -DCMAKE_BUILD_TYPE=%s",
          vim.fn.shellescape(root), vim.fn.shellescape(build_dir), build_type
        ))
        if vim.v.shell_error ~= 0 then
          vim.notify("[cmake] Configure FAILED:\n" .. cfg_out, vim.log.levels.ERROR)
          return nil
        end

        local build_out = vim.fn.system(string.format("cmake --build %s", vim.fn.shellescape(build_dir)))
        if vim.v.shell_error ~= 0 then
          vim.notify("[cmake] Build FAILED:\n" .. build_out, vim.log.levels.ERROR)
          return nil
        end

        local exe = cmake_get_exe_name(root)
        if not exe then
          vim.notify("[cmake] Could not parse executable name", vim.log.levels.ERROR)
          return nil
        end
        local binary = build_dir .. "/" .. exe
        if vim.fn.executable(binary) == 0 then
          vim.notify("[cmake] Binary not found: " .. binary, vim.log.levels.ERROR)
          return nil
        end
        return binary
      end

      local function singlefile_build(src, dir, name, ext)
        local compiler = (ext == "c") and "gcc" or (ext:match("^cpp?$") and "g++")
        if not compiler then
          vim.notify("[dap] Unsupported extension: ." .. ext, vim.log.levels.ERROR)
          return nil
        end
        local out = dir .. "/" .. name
        local output = vim.fn.system(string.format("%s -g -o %s %s", compiler, vim.fn.shellescape(out),
          vim.fn.shellescape(src)))
        if vim.v.shell_error ~= 0 then
          vim.notify("[dap] Build FAILED:\n" .. output, vim.log.levels.ERROR)
          return nil
        end
        return out
      end

      local function build(build_type)
        local src = vim.fn.expand("%:p")
        local dir = vim.fn.expand("%:p:h")
        local name = vim.fn.expand("%:t:r")
        local ext = vim.fn.expand("%:e")
        local cmake_root = cmake_find_root(dir)
        if cmake_root then
          return cmake_build(cmake_root, build_type or "Debug")
        end
        return singlefile_build(src, dir, name, ext)
      end

      -- C/C++ config
      local cpp_config = {
        name = "Build & Debug active file",
        type = "cppdbg",
        request = "launch",
        program = function()
          local bin = build("Debug")
          if not bin then error("Build failed — aborting debug session") end
          return bin
        end,
        cwd = "${workspaceFolder}",
        stopAtEntry = false,
        MIMode = "gdb",
        miDebuggerPath = vim.fn.exepath("gdb"),
        setupCommands = {
          { text = "-enable-pretty-printing", description = "enable GDB pretty printing", ignoreFailures = false },
        },
        args = {},
        console = "integratedTerminal",
      }
      dap.configurations.cpp = { cpp_config }
      dap.configurations.c = { cpp_config }

      -- Python
      local python_path = vim.fn.stdpath("data") .. "/mason/packages/debugpy/venv/bin/python"
      require("dap-python").setup(python_path)
      if not dap.configurations.python then
        dap.configurations.python = {
          {
            type = "python",
            request = "launch",
            name = "Launch current file",
            program = "${file}",
            pythonPath = python_path,
            console = "integratedTerminal",
          },
        }
      end

      -- Run terminal helper
      local dr_term_buf = nil
      local dr_term_win = nil
      local function run_in_term(cmd)
        if dr_term_buf and not vim.api.nvim_buf_is_valid(dr_term_buf) then
          dr_term_buf = nil
          dr_term_win = nil
        end
        if dr_term_win and vim.api.nvim_win_is_valid(dr_term_win) then
          vim.api.nvim_set_current_win(dr_term_win)
          vim.cmd("enew")
          dr_term_buf = vim.api.nvim_get_current_buf()
        else
          local src_win = nil
          for _, win in ipairs(vim.api.nvim_tabpage_list_wins(0)) do
            local buf = vim.api.nvim_win_get_buf(win)
            local ft = vim.api.nvim_buf_get_option(buf, "filetype")
            if not ft:match("^dap") and ft ~= "terminal" then
              src_win = win
              break
            end
          end
          if src_win then vim.api.nvim_set_current_win(src_win) end
          vim.cmd("rightbelow 10new")
          dr_term_buf = vim.api.nvim_get_current_buf()
          dr_term_win = vim.api.nvim_get_current_win()
        end
        vim.fn.termopen(cmd)
        vim.cmd("startinsert")
      end

      -- Keymaps
      local map = vim.keymap.set
      map("n", "<leader>b", dap.toggle_breakpoint, { desc = "DAP: Toggle Breakpoint" })
      map("n", "<leader>B", function()
        dap.set_breakpoint(vim.fn.input("Breakpoint condition: "))
      end, { desc = "DAP: Conditional Breakpoint" })
      map("n", "<F5>", dap.continue, { desc = "DAP: Continue / Start" })
      map("n", "<F4>", dap.restart, { desc = "DAP: Restart" })
      map("n", "<F6>", dap.step_over, { desc = "DAP: Step Over" })
      map("n", "<F7>", dap.step_into, { desc = "DAP: Step Into" })
      map("n", "<F8>", dap.step_out, { desc = "DAP: Step Out" })
      map("n", "<F9>", dap.repl.open, { desc = "DAP: Open REPL" })

      map("n", "<leader>dx", function()
        dap.terminate()
        if dapview_ok then dapview.close() end
      end, { desc = "DAP: Terminate & Close UI" })

      map("n", "<leader>dd", function()
        local ft = vim.bo.filetype
        if ft == "c" or ft == "cpp" then
          dap.run(dap.configurations.cpp[1])
        elseif ft == "python" then
          dap.run(dap.configurations.python[1])
        else
          vim.notify("[dap] No debug config for filetype: " .. ft, vim.log.levels.WARN)
        end
      end, { desc = "DAP: Build & Debug" })

      map("n", "<leader>db", function()
        local ft = vim.bo.filetype
        local ext = vim.fn.expand("%:e")
        if ft == "c" or ft == "cpp" or ext:match("^c[ppx]*$") then
          local bin = build("Release")
          if bin then vim.notify("[dap] Release binary: " .. bin, vim.log.levels.INFO) end
        else
          vim.notify("[dap] <leader>db is for C/C++ only", vim.log.levels.WARN)
        end
      end, { desc = "DAP: Build Release" })

      map("n", "<leader>dr", function()
        local ft = vim.bo.filetype
        local src = vim.fn.expand("%:p")
        local ext = vim.fn.expand("%:e")
        if ft == "python" then
          run_in_term("python3 " .. vim.fn.shellescape(src))
        elseif ft == "c" or ft == "cpp" or ext:match("^c[ppx]*$") then
          local bin = build("Debug")
          if bin then run_in_term(vim.fn.shellescape(bin)) end
        else
          vim.notify("[dap] <leader>dr: no run config for filetype: " .. ft, vim.log.levels.WARN)
        end
      end, { desc = "DAP: Build & Run (no debug)" })

      map("n", "<leader>du", function()
        if dapview_ok then
          dapview.toggle()
        else
          vim.notify("[dap-view] not available (require failed)", vim.log.levels.WARN)
        end
      end, { desc = "DAP: Toggle UI" })

      map({ "n", "v" }, "<leader>dv", function()
        require("dap.ui.widgets").hover()
      end, { desc = "DAP: Eval expression (hover)" })
    end,
  },
}
